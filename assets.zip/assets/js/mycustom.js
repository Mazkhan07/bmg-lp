// sticky header navigation scroll function
document.addEventListener( 'DOMContentLoaded', function () {
  new Splide('#Home_baazi_Rewards', {
    type: 'loop',
    perPage: 3,
    focus: 'center',
    autoplay: true,
    interval: 8000,
    flickMaxPages: 3,
    updateOnMove: true,
    pagination: false,
    padding: '10%',
    throttle: 300,
    breakpoints: {
      1024: {
        perPage: 3,
       
      },
      767: {
        perPage: 2,
    
      },
      640: {
        perPage: 1,
        padding: '50px',

  
      },
      1440: {
        perPage: 1,
        padding: '33%',

      }
      
    }
  }).mount();
});



// baazi rewards slider starts here
document.addEventListener( 'DOMContentLoaded', function () 
{
      new Splide( '#splide1',
  {
  type    : 'loop',
  perPage : 3,
  pagination : false,
  autoplay: true,
  breakpoints: {
      1024: {
        perPage: 3,
       
      },
      767: {
        perPage: 2,
    
      },
      640: {
        perPage: 1,
  
      },
  },
focus  : 'center',

}
  
  ).mount();
  } );
// baazi rewards slider ends here    


// cardsRow slider starts here    
  document.addEventListener( 'DOMContentLoaded', function () 
{
      new Splide( '#splide3',
  {
type    : 'loop',
perPage : 3,
pagination : false,
autoplay: true,
breakpoints: {
      1024: {
        perPage: 3,
       
      },
      767: {
        perPage: 2,
    
      },
      640: {
        perPage: 1,
  
      },
    },
focus  : 'center'
  }
  
  ).mount();
  } );
  
// cardsRow slider ends here 